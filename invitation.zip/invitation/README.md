# 🙏 `Akshay Weds Priyanka` 🙏

![Images](assets/images/couple1.jpg)

### Groom: Akshay Pratap Singh 🤵
Son of Mr. Rakesh Kumar Singh and Mamta Singh

### Bride: Priyanka Singh 👰
Daughter of Mr. Birendra Singh and Babita Singh


## Rituals 

### 🔴 Tilak: `13/02/2024`
Venue-6QV2+462 Ganga Bhavan, Khajuhatti,Dighwa, Gopalganj,Bihar,841413

### 🟡 Haldi and Matkor: `17/02/2024`
Venue-6QV2+462 Ganga Bhavan, Khajuhatti,Dighwa, Gopalganj,Bihar,841413

### 🟠 Vivah: `18/02/2024`
Baarat will depart from our residence to
Vill- Kanhauli PO-Hussepurnand PS-Basantpur,Siwan,Bihar,841406

## Contact
- Rakesh Singh `9163 587 351`
- Akshay Singh `8013 266 402`